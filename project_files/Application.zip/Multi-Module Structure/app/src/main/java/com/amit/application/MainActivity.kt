package com.amit.application

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.amit.application.Routes.AppRoutes
import com.amit.application.UI_screen.Chat.ChatScreen
import com.amit.application.UI_screen.Chat.PhoneContact.ContactsScreen
import com.amit.application.UI_screen.DashboardScreen
import com.amit.application.UI_screen.E_Commerce.EcommerceScreen
import com.amit.application.UI_screen.E_Commerce.ProductDetailRoute
import com.amit.application.UI_screen.E_Commerce.ProductDetailScreen
import com.amit.application.UI_screen.Login.LoginScreen
import com.amit.application.UI_screen.Profile.ProfileScreen
import com.amit.application.UI_screen.VideoPlayer.LocalVideoScreen
import com.amit.application.UI_screen.VideoPlayer.VideoPlayerScreen
import com.amit.application.UI_screen.Wallet.WalletScreen
import com.google.firebase.auth.FirebaseAuth
import dagger.hilt.android.AndroidEntryPoint
import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            // Apply your Compose Theme here (e.g., SuperAppTheme { })
            SuperAppNavigation()
        }
    }
}

@Composable
fun SuperAppNavigation() {
    val navController = rememberNavController()

    // 1. Determine the start route BEFORE initializing the NavHost.
    val startRoute: Any = if (FirebaseAuth.getInstance().currentUser != null) {
        AppRoutes.DashboardRoute
    } else {
        AppRoutes.LoginRoute
    }

    // 2. Create EXACTLY ONE NavHost
    NavHost(navController = navController, startDestination = startRoute) {

        composable<AppRoutes.LoginRoute> {
            LoginScreen(
                onNavigateToDashboard = {
                    navController.navigate(AppRoutes.DashboardRoute) {
                        popUpTo<AppRoutes.LoginRoute> { inclusive = true }
                    }
                }
            )
        }

        composable<AppRoutes.DashboardRoute> {
            DashboardScreen(
                onNavigateToProfile = { navController.navigate(AppRoutes.ProfileRoute) },
                onNavigateToEcommerce = { navController.navigate(AppRoutes.EcommerceRoute) },
                onNavigateToChat = { navController.navigate(AppRoutes.ContactListRoute) },
                onNavigateToVideo = { navController.navigate(AppRoutes.VideoPlayerRoute) },
                onNavigateToWallet = { navController.navigate(AppRoutes.WalletRoute) }
            )
        }

        composable<AppRoutes.LocalVideoRoute> {
            LocalVideoScreen(
                onVideoClick = { rawUri ->
                    // Must encode the URI string so it doesn't break URL slashes in navigation
                    val encoded = URLEncoder.encode(rawUri, StandardCharsets.UTF_8.toString())
                    navController.navigate(AppRoutes.PlayerRoute(encoded))
                }
            )
        }

        composable<AppRoutes.PlayerRoute> { backStackEntry ->
            val route = backStackEntry.toRoute<AppRoutes.PlayerRoute>()
            // Decode it back to a normal URI string before passing to the player
            val decodedUri = URLDecoder.decode(route.encodedUri, StandardCharsets.UTF_8.toString())
            VideoPlayerScreen(videoUriString = decodedUri)
        }

        composable<AppRoutes.ProfileRoute> {
            ProfileScreen(
                onBackClick = { navController.popBackStack() },
                onLogoutClick = {
                    // Sign out of Firebase
                    FirebaseAuth.getInstance().signOut()

                    // Navigate back to Login and safely clear the ENTIRE navigation history
                    navController.navigate(AppRoutes.LoginRoute) {
                        popUpTo(navController.graph.id) {
                            inclusive = true
                        }
                    }
                }
            )
        }

        composable<AppRoutes.ContactListRoute> {
            ContactsScreen(
                onBackClick = { navController.popBackStack() },
                onUserClick = { friendNumber, friendName ->
                    navController.navigate(
                        AppRoutes.ChatRoomRoute(
                            friendNumber = friendNumber,
                            friendName = friendName
                        )
                    )
                }
            )
        }

        composable<AppRoutes.ChatRoomRoute> { backStackEntry ->
            val chatArgs: AppRoutes.ChatRoomRoute = backStackEntry.toRoute()

            ChatScreen(
                onBackClick = { navController.popBackStack() }
            )
        }

        composable<AppRoutes.EcommerceRoute> {
            EcommerceScreen(
                onProductClick = { productId ->
                    navController.navigate(ProductDetailRoute(productId))
                }
            )
        }

        composable<ProductDetailRoute> { backStackEntry ->
            val detailRoute: ProductDetailRoute = backStackEntry.toRoute()

            ProductDetailScreen(
                productId = detailRoute.productId,
                onBackClick = { navController.popBackStack() }
            )
        }

        composable<AppRoutes.VideoPlayerRoute> {
            VideoPlayerScreen()
        }

        composable<AppRoutes.WalletRoute> {
            WalletScreen()
        }
    }
}

@Composable
fun PlaceholderScreen(title: String) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(title)
    }
}